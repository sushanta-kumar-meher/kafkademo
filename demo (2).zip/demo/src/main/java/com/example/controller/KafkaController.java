package com.example.controller;


import org.springframework.web.bind.annotation.RestController;



@RestController
public class KafkaController {

    private KafkaTemplate<String, String> template;

    public KafkaController(KafkaTemplate<String, String> template) {
        this.template = template;
    }

    @GetMapping("/kafka/produce")
    public void produce(@RequestParam String message) {
        template.send("Your_Topic_Name", message);
    }

}